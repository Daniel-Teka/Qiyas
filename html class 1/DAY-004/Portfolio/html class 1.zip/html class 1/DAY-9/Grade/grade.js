// 1. Declare the global history array outside the function so it saves data
let gradeHistory = [];

function calculateGrade() {
  const studentId = document.getElementById("studentId").value;
  const studentName = document.getElementById("studentName").value;
  const course = document.getElementById("course").value;
  
  const assignment = Number(document.getElementById("assignment").value);
  const final = Number(document.getElementById("final").value);
  const test = Number(document.getElementById("test").value);
  const resultDiv = document.getElementById("result");

  // 2. Score limits validation
  if (assignment > 30) {
    resultDiv.innerText = "Error: Assignment score cannot exceed 30%";
    return;
  }
  if (final > 50) {
    resultDiv.innerText = "Error: Final exam score cannot exceed 50%";
    return;
  }
  if (test > 20) {
    resultDiv.innerText = "Error: Test score cannot exceed 20%";
    return;
  }

  // 3. Calculate Grade
  const totalScore = assignment + final + test;
  let grade = "";

  if (totalScore >= 90) {
    grade = "A";
  } else if (totalScore >= 80) {
    grade = "B";
  } else if (totalScore >= 70) {
    grade = "C";
  } else if (totalScore >= 60) {
    grade = "D";
  } else {
    grade = "F";
  }

  // Display single result text box
  resultDiv.innerText = `Student ID: ${studentId}\nName: ${studentName}\nCourse: ${course}\nTotal Score: ${totalScore}%\nGrade: ${grade}`;

  // 4. Push new record into the global history array
  gradeHistory.push({
    id: studentId,
    name: studentName,
    course: course,
    total: totalScore,
    grade: grade
  });

  // 5. Update the History Display List
  renderHistory();
}

function renderHistory() {
  const historyList = document.getElementById("historyList");
  
  // Clear out old elements so they do not duplicate inside the loop
  historyList.innerHTML = "";

  // Loop through history logs and create list item objects
  for (let i = 0; i < gradeHistory.length; i++) {
    const item = gradeHistory[i];
    const liNode = document.createElement("li");
    
    // Construct text string node
    const textNode = document.createTextNode(
      `ID: ${item.id} | ${item.name} (${item.course}) ➔ Total: ${item.total}% [Grade: ${item.grade}]`
    );
    
    liNode.appendChild(textNode);
    historyList.appendChild(liNode);
  }
}
